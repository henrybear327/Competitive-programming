#include<stdio.h>

int main()
{
	int x,y;
	while(2==scanf("%d%d",&x,&y))
		printf("%d\n",x+y);
	return 0;
}
