#include<iostream>

using namespace std;

int main()
{
	long long x, y;
	while(cin>>x>>y, x)
		cout << x+y << endl;
	return 0;
}
