
#
# File:    hello.pl
# Purpose: to print hello world
# Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
#
# Sat Oct 30 13:44:36 PDT 1999
#
# caveat - this is not nice code, copy at own risk ;)
#
# $Id: hello.pl 326 2006-10-25 02:53:57Z laned $
#
#

print "Hello World.\n";

# eof
