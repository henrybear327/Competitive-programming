/*
 *
 * File:    hello.cs
 * Purpose: prints Hello World.
 * pc2@ecs.csus.edu at http://www.ecs.csus.edu/pc2
 *
 * $Id$
*/
using System;
 
public class HelloWorld
{
    static public void Main ()
    {
        Console.WriteLine ("Hello World.");
    }
}
