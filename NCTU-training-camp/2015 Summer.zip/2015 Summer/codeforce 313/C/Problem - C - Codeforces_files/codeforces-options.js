window.codeforcesOptions = [];
window.codeforcesOptions.subscribeServerUrl = "http://pubsub.codeforces.com:85/sub";